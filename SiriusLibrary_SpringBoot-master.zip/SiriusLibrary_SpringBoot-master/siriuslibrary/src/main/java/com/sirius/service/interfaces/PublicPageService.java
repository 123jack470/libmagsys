package com.sirius.service.interfaces;

import java.util.Date;

public interface PublicPageService {
    String enterNum();   // 获取页面访问次数，并加1
}
